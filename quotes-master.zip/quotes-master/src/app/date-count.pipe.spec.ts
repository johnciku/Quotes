import { DateCountPipe } from './date-count.pipe';

describe('DateCountPipe', () => {
  it('create an instance', () => {
    const pipe = new DateCountPipe();
    expect(pipe).toBeTruthy();
  });
});
