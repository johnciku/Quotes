import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>quotes</h1>
  `
})
export class AppComponent {
  qoutes = 'app';
}
