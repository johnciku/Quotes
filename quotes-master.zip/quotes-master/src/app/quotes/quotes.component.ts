import { Component, OnInit } from '@angular/core';
import {Quotes} from '../quotes'
@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {

  toogleDetails(index){
    this.quote[index].showDescription = !this.quotes[index].showDescription;
}

deleteQuote(isComplete,index){
  if (isComplete){
      let toDelete=confirm(`Are you sure you want to delete ${this.quotess[index].name}`)
      
      if(toDelete){
          this.quotes.splice(index,1)
      }
  }
}
}
  constructor() { }

  ngOnInit() {
  }

}
